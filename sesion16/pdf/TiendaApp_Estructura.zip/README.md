# TiendaApp
Proyecto base para examen final: Gestión de Productos y Pedidos usando JDBC y Hibernate.

## Requisitos
- MySQL/MariaDB
- Maven

## Configuración
Modificar `hibernate.cfg.xml` para usuario y password.

## Dependencias principales
- Hibernate
- MariaDB Connector
