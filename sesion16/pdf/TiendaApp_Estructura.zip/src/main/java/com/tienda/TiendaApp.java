package com.tienda;

public class TiendaApp {
    public static void main(String[] args) {
        System.out.println("Bienvenido al Sistema de Tienda!");
    }
}