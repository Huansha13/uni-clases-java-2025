package com.tienda.service;

import org.hibernate.Session;
import org.hibernate.Transaction;
import com.tienda.model.Pedido;
import com.tienda.model.Producto;

public class PedidoService {
    public void registrarPedido(Session session, Producto producto) {
        Transaction tx = session.beginTransaction();
        try {
            Pedido pedido = new Pedido();
            pedido.setProducto(producto);
            pedido.setFechaPedido(new java.util.Date());
            session.save(pedido);
            tx.commit();
        } catch (Exception e) {
            tx.rollback();
            e.printStackTrace();
        }
    }
}