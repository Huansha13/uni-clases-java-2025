package com.tienda.dao;

import java.sql.*;

public class ProductoDAO {
    private Connection connection;

    public ProductoDAO(Connection connection) {
        this.connection = connection;
    }

    public void insertarProducto(String nombre, double precio) throws SQLException {
        String sql = "INSERT INTO productos (nombre, precio) VALUES (?, ?)";
        PreparedStatement stmt = connection.prepareStatement(sql);
        stmt.setString(1, nombre);
        stmt.setDouble(2, precio);
        stmt.executeUpdate();
    }
}