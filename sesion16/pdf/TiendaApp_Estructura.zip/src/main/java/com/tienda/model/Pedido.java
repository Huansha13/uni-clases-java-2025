package com.tienda.model;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "pedidos")
public class Pedido {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private Date fechaPedido;

    @ManyToOne
    @JoinColumn(name = "id_producto")
    private Producto producto;

    // Getters y Setters
}